//import React from 'react';
//import { makeStyles } from '@material-ui/core/styles';
//const useStyles = makeStyles(theme => ({
//  root: {
//    width: '100%',
//    flexGrow: 1,
//    backgroundColor: theme.palette.background.paper,
//  },
//  paper: {
//    padding: theme.spacing(2),
//    textAlign: 'center',
//    color: theme.palette.info.main,
//    backgroundColor: theme.palette.action.hover
//  },
//  formLabel:{
//      backgroundColor: cyan.A200,
//      padding: theme.spacing(2),
//      textAlign: 'center',
//  }
//}));
//export const CourseDialog = ({ selectedCourse, open, onClose }) => {
//    const classes = useStyles();
//     const handleClose = () => {
//            onClose(selectedValue);
//     };
//    return (
//     <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open}>
//        <DialogTitle id="simple-dialog-title">Course Details/DialogTitle>
//    </Dialog>
//    )
//}