import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Typography from '@material-ui/core/Typography';
import ListItemText from '@material-ui/core/ListItemText';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import FormLabel from '@material-ui/core/FormLabel';
import cyan from '@material-ui/core/colors/cyan';
import Button from '@material-ui/core/Button'
const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.info.main,
    backgroundColor: theme.palette.action.hover
  },
  formLabel:{
      backgroundColor: cyan.A200,
      padding: theme.spacing(2),
      textAlign: 'center',
  }
}));

export const Courses = ({ courses }) => {
    const classes = useStyles();

    const handleCourseClick = course => event => {
        console.log("clicked", course.TITLE)
    }

    return (
     <div className={classes.root}>
      <Grid container spacing={3}>
     <Grid item xs={12} className={classes.formLabel}>
        <Typography variant="h2">MSIS Coursework</Typography>
      </Grid>
      {courses.map(course => (
        <Grid item xs={12}>
          <Paper className={classes.paper}>
            <Grid container spacing={2}>
                <Grid item xs={4}>
                    <Button onClick={handleCourseClick(course)}>{course.CLASS}</Button>
                </Grid>
                <Grid item xs={4}>{course.TITLE}</Grid>
            </Grid>
          </Paper>
        </Grid>
      ))}
      </Grid>
      </div>

    )
}